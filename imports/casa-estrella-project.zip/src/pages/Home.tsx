import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Home() {
  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <video 
            autoPlay 
            loop 
            muted 
            playsInline
            className="w-full h-full object-cover"
          >
            {/* Note: I'm using a high-quality placeholder video here. You can swap this URL with the exact .mp4 from your Zyro site. */}
            <source src="https://assets.mixkit.co/videos/preview/mixkit-swimming-pool-in-a-luxury-villa-4181-large.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-6 mt-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <h2 className="text-sm md:text-base font-medium tracking-[0.3em] uppercase mb-6">Cartagena, Colombia</h2>
            <h1 className="font-serif text-5xl md:text-8xl mb-8 leading-tight drop-shadow-lg">
              Casa Estrella<br />de San Pedro
            </h1>
            <Link 
              to="/the-villa" 
              className="inline-flex items-center gap-2 bg-white text-black px-8 py-4 text-sm font-bold tracking-widest uppercase hover:bg-black hover:text-white transition-colors"
            >
              Discover the Villa <ArrowRight size={16} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Intro Section */}
      <section className="py-24 px-6 max-w-4xl mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="font-serif text-3xl md:text-5xl mb-8 text-gray-900 leading-tight">
            The crown jewel of the Zakher portfolio.
          </h2>
          <p className="text-lg text-gray-600 leading-relaxed font-light">
            Casa Estrella de San Pedro offers an uncompromising blend of colonial grandeur and modern luxury. As our exclusive flagship property, every detail of this seven-bedroom sanctuary is managed with singular focus to provide the ultimate retreat in Cartagena.
          </p>
        </motion.div>
      </section>

      {/* Featured Grid */}
      <section className="py-12 px-6 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Link to="/the-villa" className="group relative h-[60vh] overflow-hidden bg-gray-100">
            <img 
              src="https://assets.zyrosite.com/cdn-cgi/image/format=auto,w=1920,fit=crop/Yan15JwwoxIyZnZ0/_mg_0644-m5KM1LpyNxsxzl9b.jpeg" 
              alt="Architecture" 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-500"></div>
            <div className="absolute bottom-8 left-8 text-white">
              <h3 className="font-serif text-3xl mb-2">The Architecture</h3>
              <span className="text-sm font-medium tracking-widest uppercase flex items-center gap-2">
                Explore <ArrowRight size={14} />
              </span>
            </div>
          </Link>
          
          <Link to="/amenities" className="group relative h-[60vh] overflow-hidden bg-gray-100">
            <img 
              src="https://assets.zyrosite.com/cdn-cgi/image/format=auto,w=1920,fit=crop/Yan15JwwoxIyZnZ0/_mg_0389-mp8WRqw9M5T49WDb.jpeg" 
              alt="Amenities" 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-500"></div>
            <div className="absolute bottom-8 left-8 text-white">
              <h3 className="font-serif text-3xl mb-2">Resort Amenities</h3>
              <span className="text-sm font-medium tracking-widest uppercase flex items-center gap-2">
                Discover <ArrowRight size={14} />
              </span>
            </div>
          </Link>
        </div>
      </section>
    </div>
  );
}
